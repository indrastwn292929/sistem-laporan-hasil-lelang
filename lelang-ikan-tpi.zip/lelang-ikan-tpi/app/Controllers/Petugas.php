<?php namespace App\Controllers;

use App\Models\KarcisBakulModel;
use App\Models\KarcisPemilikKapalModel;

class Petugas extends BaseController
{
    protected $karcisBakulModel;
    protected $karcisPemilikKapalModel;
    
    public function __construct()
    {
        $this->karcisBakulModel = new KarcisBakulModel();
        $this->karcisPemilikKapalModel = new KarcisPemilikKapalModel();
    }
    
    public function index()
    {
        $data = [
            'title' => 'Dashboard Petugas TPI',
            'nama_lengkap' => session()->get('nama_lengkap')
        ];
        return view('petugas/dashboard', $data);
    }
    
    // === INPUT KARCIS BAKUL ===
    public function inputKarcisBakul()
    {
        if ($this->request->getMethod() === 'POST') {
            // Simpan data karcis bakul
            $data = [
                'nomor_karcis' => $this->request->getPost('nomor_karcis'),
                'nama_bakul' => $this->request->getPost('nama_bakul'),
                'alamat' => $this->request->getPost('alamat'),
                'berat_ikan' => $this->request->getPost('berat_ikan'),
                'jumlah_karcis' => $this->request->getPost('jumlah_karcis'),
                'jumlah_pembelian' => $this->request->getPost('jumlah_pembelian'),
                'jasa_lelang' => $this->request->getPost('jasa_lelang'),
                'lain_lain' => $this->request->getPost('lain_lain') ?? 0,
                'total' => $this->request->getPost('total'),
                'jumlah_bayar' => $this->request->getPost('jumlah_bayar'),
                'created_by' => session()->get('user_id'),
                'status' => 'pending'
            ];
            
            if ($this->karcisBakulModel->save($data)) {
                return redirect()->to('/petugas/daftar-karcis-bakul')->with('success', 'Karcis bakul berhasil disimpan!');
            } else {
                return redirect()->back()->with('error', 'Gagal menyimpan karcis bakul!');
            }
        }
        
        $data = ['title' => 'Input Karcis Bakul'];
        return view('petugas/input_karcis_bakul', $data);
    }
    
    // === INPUT KARCIS PEMILIK KAPAL ===
    public function inputKarcisPemilikKapal()
    {
        if ($this->request->getMethod() === 'POST') {
            // Simpan data karcis pemilik kapal
            $data = [
                'nomor_karcis' => $this->request->getPost('nomor_karcis'),
                'nama_nelayan' => $this->request->getPost('nama_nelayan'),
                'alamat' => $this->request->getPost('alamat'),
                'berat_ikan' => $this->request->getPost('berat_ikan'),
                'jumlah_karcis' => $this->request->getPost('jumlah_karcis'),
                'jumlah_penjualan' => $this->request->getPost('jumlah_penjualan'),
                'jasa_lelang' => $this->request->getPost('jasa_lelang'),
                'lain_lain' => $this->request->getPost('lain_lain') ?? 0,
                'total' => $this->request->getPost('total'),
                'jumlah_dibayar' => $this->request->getPost('jumlah_dibayar'),
                'created_by' => session()->get('user_id'),
                'status' => 'pending'
            ];
            
            if ($this->karcisPemilikKapalModel->save($data)) {
                return redirect()->to('/petugas/daftar-karcis-pemilik-kapal')->with('success', 'Karcis pemilik kapal berhasil disimpan!');
            } else {
                return redirect()->back()->with('error', 'Gagal menyimpan karcis pemilik kapal!');
            }
        }
        
        $data = ['title' => 'Input Karcis Pemilik Kapal'];
        return view('petugas/input_karcis_pemilik_kapal', $data);
    }
    
    // === DAFTAR KARCIS ===
    public function daftarKarcisBakul()
    {
        $data = [
            'title' => 'Daftar Karcis Bakul',
            'karcis' => $this->karcisBakulModel->where('created_by', session()->get('user_id'))->findAll()
        ];
        return view('petugas/daftar_karcis_bakul', $data);
    }
    
    public function daftarKarcisPemilikKapal()
    {
        $data = [
            'title' => 'Daftar Karcis Pemilik Kapal',
            'karcis' => $this->karcisPemilikKapalModel->where('created_by', session()->get('user_id'))->findAll()
        ];
        return view('petugas/daftar_karcis_pemilik_kapal', $data);
    }
}