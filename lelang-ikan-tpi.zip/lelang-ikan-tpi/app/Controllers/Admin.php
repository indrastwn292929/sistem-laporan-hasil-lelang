<?php namespace App\Controllers;

class Admin extends BaseController
{
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/auth/login');
        }
        
        $data = [
            'title' => 'Dashboard Admin',
            'user' => [
                'nama' => session()->get('nama_lengkap'),
                'role' => session()->get('role')
            ]
        ];
        
        return view('admin/dashboard', $data);
    }
}