<?php namespace App\Controllers;

class Test extends BaseController
{
    public function index()
    {
        return "Test berhasil! Sistem berjalan.";
    }
    
    public function login()
    {
        return view('auth/login');
    }
}