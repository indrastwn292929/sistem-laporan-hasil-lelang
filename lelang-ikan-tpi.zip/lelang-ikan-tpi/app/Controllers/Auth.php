<?php namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        // Log start dengan method info
        $this->writeLog("=== LOGIN PAGE ACCESSED ===");
        $this->writeLog("Request Method: " . $this->request->getMethod());
        $this->writeLog("POST Data: " . print_r($this->request->getPost(), true));
        
        // PERBAIKI INI: Gunakan uppercase 'POST'
        if ($this->request->getMethod() === 'POST') {
            $this->writeLog("✅ POST METHOD DETECTED");
            
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');
            
            $this->writeLog("Login attempt: username=$username, password=$password");
            
            $userModel = new UserModel();
            $user = $userModel->where('username', $username)->first();
            
            if ($user) {
                $this->writeLog("User found: " . $user['username']);
                
                if ($user['password'] === $password) {
                    $this->writeLog("✅ Password CORRECT");
                    
                    // Set session
                    session()->set('user_id', $user['id']);
                    session()->set('username', $user['username']);
                    session()->set('nama_lengkap', $user['nama_lengkap']);
                    session()->set('role', $user['role']);
                    session()->set('logged_in', true);
                    
                    $this->writeLog("✅ Session SET - Redirecting to /admin");
                    
                    // Redirect
                    return redirect()->to('/admin');
                } else {
                    $this->writeLog("❌ Password WRONG");
                    return redirect()->back()->with('error', 'Password salah!');
                }
            } else {
                $this->writeLog("❌ User NOT FOUND");
                return redirect()->back()->with('error', 'User tidak ditemukan!');
            }
        } else {
            $this->writeLog("❌ NOT POST METHOD - Showing form");
            $this->writeLog("Actual method: " . $this->request->getMethod());
        }
        
        $this->writeLog("Showing login form");
        return view('auth/login');
    }
    
    private function writeLog($message)
    {
        $logFile = WRITEPATH . 'logs/auth_debug.log';
        $timestamp = date('Y-m-d H:i:s');
        file_put_contents($logFile, "[$timestamp] $message\n", FILE_APPEND | LOCK_EX);
    }
    
    public function logout()
    {
        session()->destroy();
        return redirect()->to('/auth/login');
    }
    
    public function index()
    {
        return $this->login();
    }
}