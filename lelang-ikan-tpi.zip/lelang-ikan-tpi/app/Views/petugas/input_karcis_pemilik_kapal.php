<?= $this->include('layouts/header') ?>

<h2>Input Karcis Pemilik Kapal</h2>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
<?php endif; ?>

<form method="post" action="<?= site_url('/petugas/input-karcis-pemilik-kapal') ?>">
    <div class="row">
        <div class="col-md-6">
            <div class="mb-3">
                <label for="nomor_karcis" class="form-label">Nomor Karcis</label>
                <input type="text" class="form-control" id="nomor_karcis" name="nomor_karcis" required>
            </div>
            <div class="mb-3">
                <label for="nama_nelayan" class="form-label">Nama Nelayan/Kapal</label>
                <input type="text" class="form-control" id="nama_nelayan" name="nama_nelayan" required>
            </div>
            <div class="mb-3">
                <label for="alamat" class="form-label">Alamat</label>
                <textarea class="form-control" id="alamat" name="alamat" rows="3" required></textarea>
            </div>
            <div class="mb-3">
                <label for="berat_ikan" class="form-label">Berat Ikan (kg)</label>
                <input type="number" step="0.01" class="form-control" id="berat_ikan" name="berat_ikan" required>
            </div>
            <div class="mb-3">
                <label for="jumlah_karcis" class="form-label">Jumlah Karcis</label>
                <input type="number" class="form-control" id="jumlah_karcis" name="jumlah_karcis" required>
            </div>
        </div>
        <div class="col-md-6">
            <div class="mb-3">
                <label for="jumlah_penjualan" class="form-label">Jumlah Penjualan (Rp)</label>
                <input type="number" step="0.01" class="form-control" id="jumlah_penjualan" name="jumlah_penjualan" required>
            </div>
            <div class="mb-3">
                <label for="jasa_lelang" class="form-label">Jasa Lelang (Rp)</label>
                <input type="number" step="0.01" class="form-control" id="jasa_lelang" name="jasa_lelang" required>
            </div>
            <div class="mb-3">
                <label for="lain_lain" class="form-label">Lain-lain (Rp)</label>
                <input type="number" step="0.01" class="form-control" id="lain_lain" name="lain_lain" value="0">
            </div>
            <div class="mb-3">
                <label for="total" class="form-label">Total (Rp)</label>
                <input type="number" step="0.01" class="form-control" id="total" name="total" required>
            </div>
            <div class="mb-3">
                <label for="jumlah_dibayar" class="form-label">Jumlah Dibayar (Rp)</label>
                <input type="number" step="0.01" class="form-control" id="jumlah_dibayar" name="jumlah_dibayar" required>
            </div>
        </div>
    </div>
    <button type="submit" class="btn btn-primary">Simpan</button>
    <a href="<?= site_url('/petugas') ?>" class="btn btn-secondary">Kembali</a>
</form>

<?= $this->include('layouts/footer') ?>