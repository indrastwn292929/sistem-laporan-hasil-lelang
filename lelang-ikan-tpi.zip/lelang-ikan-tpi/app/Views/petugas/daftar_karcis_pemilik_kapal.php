<?= $this->include('layouts/header') ?>

<h2>Daftar Karcis Pemilik Kapal</h2>

<?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nomor Karcis</th>
                        <th>Nama Nelayan/Kapal</th>
                        <th>Berat Ikan</th>
                        <th>Total Penjualan</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($karcis as $k): ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $k['nomor_karcis'] ?></td>
                        <td><?= $k['nama_nelayan'] ?></td>
                        <td><?= $k['berat_ikan'] ?> kg</td>
                        <td>Rp <?= number_format($k['total'], 0, ',', '.') ?></td>
                        <td>
                            <?php if ($k['status'] == 'pending'): ?>
                                <span class="badge bg-warning">Menunggu Verifikasi</span>
                            <?php elseif ($k['status'] == 'verified'): ?>
                                <span class="badge bg-success">Terverifikasi</span>
                            <?php else: ?>
                                <span class="badge bg-danger">Ditolak</span>
                            <?php endif; ?>
                        </td>
                        <td><?= date('d/m/Y', strtotime($k['created_at'])) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($karcis)): ?>
                    <tr>
                        <td colspan="7" class="text-center">Belum ada data karcis</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<a href="<?= site_url('/petugas') ?>" class="btn btn-secondary mt-3">Kembali</a>

<?= $this->include('layouts/footer') ?>