<?= $this->include('layouts/header') ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="background: linear-gradient(135deg, #0c0c2d 0%, #1a1a4b 100%); min-height: 100vh; position: relative; overflow: hidden;">
    
    <!-- Space Ocean Background -->
    <div class="space-ocean">
        <div class="star star-1"></div>
        <div class="star star-2"></div>
        <div class="star star-3"></div>
        <div class="star star-4"></div>
        <div class="planet"></div>
        <div class="satellite">🛰️</div>
    </div>

    <!-- Holographic Header -->
    <div class="position-relative z-2">
        <div class="hologram-header rounded-3 mb-4 text-center py-5">
            <h1 class="display-4 fw-bold hologram-text">
                <i class="bi bi-stars me-3"></i>Mission Control
            </h1>
            <p class="lead fw-normal">Welcome, <strong class="cyber-glow"><?= session()->get('nama_lengkap') ?></strong></p>
            <div class="cyber-badge">
                <span class="blink">⚡</span> ADMIN ACCESS ACTIVATED
            </div>
        </div>

        <!-- Cyberpunk Statistics Grid -->
        <div class="row g-4 mb-4">
            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch>
                    <div class="card-body text-center">
                        <div class="cyber-icon">🚨</div>
                        <h3 class="cyber-number">12</h3>
                        <small>PENDING</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 60%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch>
                    <div class="card-body text-center">
                        <div class="cyber-icon">✅</div>
                        <h3 class="cyber-number">89%</h3>
                        <small>APPROVED</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 89%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch>
                    <div class="card-body text-center">
                        <div class="cyber-icon">💰</div>
                        <h3 class="cyber-number">48.7</h3>
                        <small>MILLION</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 75%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch>
                    <div class="card-body text-center">
                        <div class="cyber-icon">👥</div>
                        <h3 class="cyber-number">02</h3>
                        <small>OPERATORS</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 100%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch>
                    <div class="card-body text-center">
                        <div class="cyber-icon">📈</div>
                        <h3 class="cyber-number">+15%</h3>
                        <small>GROWTH</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 15%"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-2 col-md-4 col-6">
                <div class="cyber-card" data-glitch>
                    <div class="card-body text-center">
                        <div class="cyber-icon">🔒</div>
                        <h3 class="cyber-number">100%</h3>
                        <small>SECURE</small>
                        <div class="cyber-bar">
                            <div class="cyber-progress" style="width: 100%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Holographic Control Panel -->
        <div class="row g-4 mb-4">
            <div class="col-lg-6">
                <div class="hologram-panel">
                    <div class="panel-header">
                        <h4><i class="bi bi-cpu-fill me-2"></i>SYSTEM CONTROLS</h4>
                    </div>
                    <div class="panel-body">
                        <div class="control-grid">
                            <a href="<?= site_url('/admin/verifikasi-karcis-bakul') ?>" class="control-item verify-control">
                                <div class="control-icon">🔍</div>
                                <span>VERIFICATION</span>
                                <div class="status-dot online"></div>
                            </a>
                            <a href="<?= site_url('/admin/laporan') ?>" class="control-item analytics-control">
                                <div class="control-icon">📊</div>
                                <span>ANALYTICS</span>
                                <div class="status-dot online"></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="hologram-panel">
                    <div class="panel-header">
                        <h4><i class="bi bi-tools me-2"></i>MANAGEMENT TOOLS</h4>
                    </div>
                    <div class="panel-body">
                        <div class="control-grid">
                            <a href="<?= site_url('/admin/laporan') ?>" class="control-item report-control">
                                <div class="control-icon">📋</div>
                                <span>REPORTS</span>
                                <div class="status-dot online"></div>
                            </a>
                            <a href="<?= site_url('/admin/cetak-laporan') ?>" class="control-item print-control">
                                <div class="control-icon">🖨️</div>
                                <span>PRINT</span>
                                <div class="status-dot online"></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Live System Monitor -->
        <div class="hologram-panel large">
            <div class="panel-header">
                <h4><i class="bi bi-radar me-2"></i>LIVE SYSTEM MONITOR</h4>
            </div>
            <div class="panel-body">
                <div class="system-grid">
                    <div class="system-item">
                        <div class="system-icon">💾</div>
                        <div class="system-info">
                            <span>DATA WAREHOUSE</span>
                            <div class="system-status online">ONLINE</div>
                        </div>
                    </div>
                    <div class="system-item">
                        <div class="system-icon">🖥️</div>
                        <div class="system-info">
                            <span>CONTROL TOWER</span>
                            <div class="system-status online">OPERATIONAL</div>
                        </div>
                    </div>
                    <div class="system-item">
                        <div class="system-icon">🔐</div>
                        <div class="system-info">
                            <span>SECURITY GRID</span>
                            <div class="system-status online">ACTIVE</div>
                        </div>
                    </div>
                    <div class="system-item">
                        <div class="system-icon">☁️</div>
                        <div class="system-info">
                            <span>BACKUP SYSTEM</span>
                            <div class="system-status online">SYNCED</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<style>
/* Space Ocean Background */
.space-ocean {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    z-index: 1;
}

.star {
    position: absolute;
    background: white;
    border-radius: 50%;
    animation: twinkle 3s infinite;
}

.star-1 { width: 2px; height: 2px; top: 20%; left: 10%; animation-delay: 0s; }
.star-2 { width: 3px; height: 3px; top: 40%; left: 80%; animation-delay: 1s; }
.star-3 { width: 1px; height: 1px; top: 60%; left: 30%; animation-delay: 2s; }
.star-4 { width: 2px; height: 2px; top: 80%; left: 60%; animation-delay: 1.5s; }

@keyframes twinkle {
    0%, 100% { opacity: 0.3; }
    50% { opacity: 1; }
}

.planet {
    position: absolute;
    top: 10%;
    right: 10%;
    width: 100px;
    height: 100px;
    background: radial-gradient(circle, #4a4a8a, #2a2a5a);
    border-radius: 50%;
    animation: rotate 20s infinite linear;
}

.satellite {
    position: absolute;
    top: 30%;
    right: 20%;
    font-size: 2rem;
    animation: orbit 15s infinite linear;
}

@keyframes rotate {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

@keyframes orbit {
    0% { transform: rotate(0deg) translateX(150px) rotate(0deg); }
    100% { transform: rotate(360deg) translateX(150px) rotate(-360deg); }
}

/* Holographic Effects */
.hologram-header {
    background: rgba(255,255,255,0.05);
    backdrop-filter: blur(20px);
    border: 1px solid rgba(255,255,255,0.1);
    position: relative;
    overflow: hidden;
}

.hologram-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(0,255,255,0.1), transparent);
    animation: hologramScan 4s infinite;
}

@keyframes hologramScan {
    0% { left: -100%; }
    100% { left: 100%; }
}

.hologram-text {
    background: linear-gradient(45deg, #00ffff, #ff00ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    text-shadow: 0 0 30px rgba(0,255,255,0.5);
}

/* Cyberpunk Cards */
.cyber-card {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(0,255,255,0.3);
    border-radius: 10px;
    padding: 20px;
    position: relative;
    overflow: hidden;
    transition: all 0.3s ease;
}

.cyber-card:hover {
    border-color: #00ffff;
    box-shadow: 0 0 20px rgba(0,255,255,0.5);
    transform: translateY(-5px);
}

.cyber-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(0,255,255,0.1), transparent);
    transition: left 0.5s;
}

.cyber-card:hover::before {
    left: 100%;
}

.cyber-number {
    font-size: 2rem;
    background: linear-gradient(45deg, #00ffff, #ff00ff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin: 10px 0;
}

.cyber-bar {
    background: rgba(255,255,255,0.1);
    height: 4px;
    border-radius: 2px;
    margin-top: 10px;
    overflow: hidden;
}

.cyber-progress {
    height: 100%;
    background: linear-gradient(90deg, #00ffff, #ff00ff);
    animation: progressLoad 2s ease-in-out;
}

@keyframes progressLoad {
    from { width: 0%; }
}

/* Glitch Effect */
[data-glitch] {
    position: relative;
}

[data-glitch]::after {
    content: attr(data-text);
    position: absolute;
    left: 2px;
    text-shadow: -1px 0 red;
    top: 0;
    color: white;
    background: black;
    overflow: hidden;
    clip: rect(0, 900px, 0, 0);
    animation: noise-anim 2s infinite linear alternate-reverse;
}

[data-glitch]::before {
    content: attr(data-text);
    position: absolute;
    left: -2px;
    text-shadow: 1px 0 blue;
    top: 0;
    color: white;
    background: black;
    overflow: hidden;
    clip: rect(0, 900px, 0, 0);
    animation: noise-anim-2 3s infinite linear alternate-reverse;
}

@keyframes noise-anim {
    0% { clip: rect(61px, 9999px, 52px, 0); }
    5% { clip: rect(70px, 9999px, 47px, 0); }
    10% { clip: rect(20px, 9999px, 97px, 0); }
    15% { clip: rect(52px, 9999px, 64px, 0); }
    20% { clip: rect(23px, 9999px, 20px, 0); }
    25% { clip: rect(37px, 9999px, 59px, 0); }
    30% { clip: rect(97px, 9999px, 93px, 0); }
    35% { clip: rect(10px, 9999px, 77px, 0); }
    40% { clip: rect(15px, 9999px, 18px, 0); }
    45% { clip: rect(100px, 9999px, 5px, 0); }
    50% { clip: rect(73px, 9999px, 82px, 0); }
    55% { clip: rect(9px, 9999px, 100px, 0); }
    60% { clip: rect(86px, 9999px, 30px, 0); }
    65% { clip: rect(77px, 9999px, 63px, 0); }
    70% { clip: rect(84px, 9999px, 29px, 0); }
    75% { clip: rect(8px, 9999px, 14px, 0); }
    80% { clip: rect(55px, 9999px, 27px, 0); }
    85% { clip: rect(64px, 9999px, 9px, 0); }
    90% { clip: rect(100px, 9999px, 83px, 0); }
    95% { clip: rect(46px, 9999px, 84px, 0); }
    100% { clip: rect(82px, 9999px, 29px, 0); }
}

/* Hologram Panels */
.hologram-panel {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(0,255,255,0.2);
    border-radius: 15px;
    backdrop-filter: blur(10px);
}

.panel-header {
   