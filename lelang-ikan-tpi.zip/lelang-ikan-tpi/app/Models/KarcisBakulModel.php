<?php
namespace App\Models;

use CodeIgniter\Model;

class KarcisBakulModel extends Model
{
    protected $table = 'karcis_bakul';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'nomor_karcis', 'nama_bakul', 'alamat', 'berat_ikan', 'jumlah_karcis',
        'jumlah_pembelian', 'jasa_lelang', 'lain_lain', 'total', 'jumlah_bayar',
        'created_by', 'status'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = ''; // Tidak ada updated_at karena tidak perlu update

    // Validation rules
    protected $validationRules = [
        'nomor_karcis' => 'required|is_unique[karcis_bakul.nomor_karcis]',
        'nama_bakul' => 'required',
        'alamat' => 'required',
        'berat_ikan' => 'required|numeric',
        'jumlah_karcis' => 'required|numeric',
        'jumlah_pembelian' => 'required|numeric',
        'jasa_lelang' => 'required|numeric',
        'total' => 'required|numeric',
        'jumlah_bayar' => 'required|numeric'
    ];

    protected $validationMessages = [
        'nomor_karcis' => [
            'is_unique' => 'Nomor karcis ini sudah digunakan.'
        ]
    ];
}