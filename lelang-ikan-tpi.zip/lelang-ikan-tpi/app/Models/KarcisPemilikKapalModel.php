<?php namespace App\Models;

use CodeIgniter\Model;

class KarcisPemilikKapalModel extends Model
{
    protected $table = 'karcis_pemilik_kapal';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'nomor_karcis', 'nama_nelayan', 'alamat', 'berat_ikan', 
        'jumlah_karcis', 'jumlah_penjualan', 'jasa_lelang', 
        'lain_lain', 'total', 'jumlah_dibayar', 'created_by', 'status'
    ];
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
}