<?php namespace Config;

$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(true); // UBAH INI KE true

// Auth Routes
$routes->get('/', 'Auth::login');
$routes->get('/auth/login', 'Auth::login');
$routes->post('/auth/login', 'Auth::login');
$routes->get('/auth/logout', 'Auth::logout');

// Admin Routes
$routes->get('/admin', 'Admin::index');

// Petugas Routes
$routes->get('/petugas', 'Petugas::index');

// Debug Routes
$routes->get('/debug', 'Debug::index');

$routes->get('/simple-test', 'SimpleTest::index');
$routes->match(['get', 'post'], '/simple-test/login', 'SimpleTest::login');

// Petugas Routes
$routes->get('/petugas/input-karcis-bakul', 'Petugas::inputKarcisBakul', ['filter' => 'auth']);
$routes->post('/petugas/input-karcis-bakul', 'Petugas::inputKarcisBakul', ['filter' => 'auth']);
$routes->get('/petugas/input-karcis-pemilik-kapal', 'Petugas::inputKarcisPemilikKapal', ['filter' => 'auth']);
$routes->post('/petugas/input-karcis-pemilik-kapal', 'Petugas::inputKarcisPemilikKapal', ['filter' => 'auth']);
$routes->get('/petugas/daftar-karcis-bakul', 'Petugas::daftarKarcisBakul', ['filter' => 'auth']);
$routes->get('/petugas/daftar-karcis-pemilik-kapal', 'Petugas::daftarKarcisPemilikKapal', ['filter' => 'auth']);

$routes->get('/debug-session', 'SessionDebug::index', ['filter' => 'auth']);

// Tambahkan route berikut:
$routes->get('karcis-bakul', 'KarcisBakul::index');
$routes->post('karcis-bakul/simpan', 'KarcisBakul::simpan');
$routes->get('karcis-bakul/sukses', 'KarcisBakul::sukses');